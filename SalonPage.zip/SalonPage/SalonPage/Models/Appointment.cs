﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SalonPage.Models
{
    public class Appointment
    {
        public int Id { get; set; }

        [Display(Name ="Customer Name")]
        [Range(1,100)]
        [Required]
        public string CustomerName { get; set; }

        [Display(Name = "Customer Phone Number")]
        [Range(10,11)]
        public long CustomerPhoneNumber { get; set; }

        [Display(Name = "Service Time")]
        public DateTime ServiceTime { get; set; }

        [Display(Name = "Hair Service")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z\s]*$")]
        [Required]
        public string HairService { get; set; }

        [Display(Name = "Service Price")]
        [DataType(DataType.Currency)]
        [Column(TypeName ="double(18,2)")]
        public double ServicePrice { get; set; }
    }
}
